# 分阶段实施计划

本文件延续用户确认的 7 个必做阶段和 1 个可选阶段。只有当前用户指定阶段被授权执行。

| 阶段 | 范围 | 前置条件 | 验收与退出条件 | 当前状态 |
|---|---|---|---|---|
| 1 | 代码盘点、版本比较、环境和入口探测、迁移清单 | 工作区源码可读 | 文档、可复查证据、所有未通过项明确 | 盘点完成；训练基线被环境阻塞 |
| 2 | PyMARL 核心包；先 QMIX，再 COMA/VDN/IQL/QTRAN 等原版配置 | 独立 Python/PyTorch 环境；确认配置兼容 | 可安装；原输出对照；小环境有效更新；保存加载；真实 SMAC 单列 | 本地通过；真实 SMAC 环境阻塞 |
| 3 | RODE、RODE-HMF、HMF 补货实现与变体 | 阶段 2 schema/适配约定；补货依赖 | roles/mean-field 时间和维度正确；各迁移项有效更新；独立未接通变体有结论 | 本地接入验收完成并停止；真实环境、5 个实验及动态分组/扩角色等未通过 |
| 4 | 寇谦 offline/preference、old_src、奖励模型、数据工具 | 阶段 2；torch 数据加载；核实配对和路径 | 至少普通离线与偏好闭环；随后逐项覆盖；真实数据与合成数据分开验证 | 本地与真实 3m 数据短更新通过；来源缺项、交互流程和真实环境/效果未通过，阶段结束后停止 |
| 5 | SADMA 版本选择与同步训练、PPO 和 QMIX、环境适配 | 阶段 2；版本差异评审 | 同/离策略数据正确；时间位置对照；保存加载补齐；重复运行可关闭资源 | 本地同步接入与验收完成；连续动作/真实环境/来源问题保留，完成后停止 |
| 6 | ZMQ 训练/采样/推理与参数交换 | 阶段 5；稳定数据协议和 pyzmq | 本机多进程闭环、异常退出和端口释放；跨机器另验 | Windows 回环多进程与独立角色通过；故障/超时/端口释放通过；跨机、真实环境、持续评估 worker 等未验，完成后停止 |
| 7 | 剩余能力迁移、干净安装、wheel、示例和验证报告 | 各前置阶段有证据或显式阻塞 | 来源追踪完整；真实可运行产物；已实现/本地/真实状态分开；文档支持矩阵 | 0.7.0 支持子集交付验收结束；220 测试、独立安装与真实数据/回环验证通过；全部未通过项保留于 KNOWN_ISSUES，不表示全部原实验完成 |
| 8 可选 | FastAPI/Vue 平台、K8s Operator 与包联调 | 阶段 7 可安装产物；数据库/集群等 | 提交/取消/日志/结果/失败链路验证；集群验证单列 | 不属于当前执行范围 |

## 后续用户授权：内部分发包

Windows x64 和 Linux x86_64 CPU / CPython 3.12 两版已准备。Windows 为完整离线包并完成本机全新环境验收；Linux 为接收方联网补齐 hf-xet 的混合版，按用户要求不在此电脑进行 Linux 功能测试。原算法支持范围、383 行迁移清单及未通过项不变。接收方须预装 Python/系统运行库；真实数据与仿真器另行提供。产物、安装流程和实际验证层次见 INTERNAL_DISTRIBUTION.md、INTERNAL_WINDOWS_REPORT.md、INTERNAL_LINUX_REPORT.md。此补充不进入 Web/K8s 阶段。

## 阶段 2 的第一条训练链路

优先建立项目隔离环境，并验证 CPU PyTorch 与 NumPy；先迁移原版 PyMARL QMIX。

```text
Python API / CLI
  → 配置加载与算法组合验证
  → 小型确定性离散多智能体环境
  → EpisodeRunner / BasicMAC / RNNAgent
  → EpisodeBatch / ReplayBuffer
  → QLearner / QMixer
  → 一次真实梯度更新
  → checkpoint 保存、重新加载、评估
```

该链路已在确定性 toy 中通过，真实 SMAC 3m 因外部环境缺失未验证。第 2 阶段详见 STAGE2_REPORT.md。第 1 阶段的依赖缺失记录保留为历史证据。

## 各阶段优先解决的已知问题

- 阶段 2：PATH 的 Python 是不可启动别名；应用 Python 无 torch/yaml/sacred；PyMARL 的 yaml.load、collections.Mapping、os._exit 和资源路径需兼容处理。
- 阶段 3：HMF 18 文件已逐项核实，13 个默认算法/固定组变体接通，5 个具体失败原因见 STAGE3_REPORT.md。动态 IPC/K-means、RODE 扩角色后的优化器/分组维度、q 角色组件继续保留为欠项；真实补货/SMAC 缺后端与资产。固定组通过不能替代动态执行验收。
- 阶段 4：BC/CPL 首条链路、17 个策略调用配置、6 种奖励模型与多标签初始轮次已经接入并验证短更新。hacpl/maicpl/maidpo 缺 Learner；BCQ 风格 QLearner 的三输出与所配 Controller 不兼容；ACPL 配置不完整；old_src 的参考策略、个体终止和 agent_state 缺失。NMR/PrefTransformer 等来源问题保留；完整交互/无监督/联合训练及后续信任筛选未全部通过。逐项原因见 STAGE4_REPORT.md 和矩阵，不能以默认分支通过替代。
- 阶段 5：已比较 4 份 SADMA，选王思哲算法类并保留易才润开源/闭源配置，7 个配置和 6 个额外分支完成短更新。QMIX/VDN 使用来源回放，PPO 使用一次消费的新数据；补齐旧概率/价值/策略版本及完整 checkpoint。MADDPG 空 Policy、连续电网 schema 与资产、真实 SMAC/补货/CityFlow、GPU、单环境以外执行仍未通过，详见 STAGE5_REPORT.md 和 SADMA_VERSION_SELECTION.md。
- 阶段 6：已实现新版本化 ZMQ 协议、训练/采样/推理角色、参数摘要确认、有界信用/HWM 和有限超时。SADMA Q/VDN 支持 sync/async，普通 PPO 仅 sync，async PPO 显式 use_vtrace=true；其他家族不自动接入。没有远程主机，跨机/GPU/真实环境未验；原持续 EvaluateWorker、旧共享 IPC 与多 Learner 未迁移，具体配置覆盖见 STAGE6_REPORT.md。
- 阶段 7：矩阵中所有项有实现、重复处理、范围决策或阻塞结论；保留来源和失败证据。

## 阻塞处理与状态更新

阶段 1 的完成是“盘点材料完成”，不是“原项目已跑通”。外部条件缺失不阻止准备规格和静态清单。后续阶段也可以继续独立工作，但真实环境/数据验收不降级成通过。

大规模收敛实验在本计划之外，若用户后续要求，另建实验清单和计算预算。

## 0.8.0 工程应用打包

按用户最新授权连续完成：应用规格与模板 → 仓储补货 → 交通信号 → 电网连续动作 → Windows/Linux发行包 → 私有GitHub发布。用户自行实验，本轮不启动训练或仿真，仅检查和构建；新实现单独标为待用户测试。GitHub发布状态以实际Release回执为准。
